redJSR Wiki starter website

Files:
- index.html: home page
- about.html: About the Creator
- style.css: plain dark-mode styling
- characters/: individual character pages
- images/: add character images here
- logo.PNG: place your logo file at the repository root

IMPORTANT:
1. Add your actual logo.PNG to the repository root.
2. Add each character image to images/ using the exact filename displayed on their page.
3. Upload these files to the root of your GitHub repository (keep the characters/ and images/ folders).
4. No release date or release schedule is included.
5. TIAOJ is described as a comic series; no episode pages are included.
